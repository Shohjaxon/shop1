const API_KEY = "f1ebce89-e4ee6397-6aa32473-70976956";
const API_URL = "https://fortniteapi.io/v1/shop?lang=en";

export { API_KEY, API_URL };
