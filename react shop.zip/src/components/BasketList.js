import React from "react";

export default function BasketList(props) {
  const { handleBasketShow } = props;
  return (
    <div className="bgBasket">
      <ul className="collection basket-list">
        <li className="collection-item active">Basket</li>
        <li className="collection-item">Basket is empty</li>
        <li className="collection-item active">
          <p>Total cost: 1200 $</p>
        </li>
        <i onClick={handleBasketShow} className="material-icons basket-close">close</i>
      </ul>
    </div>
  );
}
